document.addEventListener("DOMContentLoaded", function() {
    const logoImg = document.getElementById("l_logo");
    const imageName = document.getElementById("imageName");

    logoImg.addEventListener("mouseover", function() {
        imageName.textContent = "Atlantic";
    });
    logoImg.addEventListener("mouseout", function() {
        imageName.textContent = "";
    });
});
